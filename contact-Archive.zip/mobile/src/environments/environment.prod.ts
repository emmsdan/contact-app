const url = "https://api.emmsdan.com.ng";

export const environment = {
  production: true,
  url,

};
