const url = "https://api.ehcontact.emmsdan.com.ng";
// const url = "http://localhost:8080";

export const environment = {
  production: false,
  url,
  social: {
    facebookId: "387590411698548",
  },
  userStorageName: "emmsdan.signed-in.user",
};
