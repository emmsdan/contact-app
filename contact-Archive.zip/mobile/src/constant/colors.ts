export default {
    background: "#edf5fc",
    grayDark: "#8F92A1",
    grayLight: "#EEEEEE",
    icon: "#2E3A59",
    blue: "#18224C"
}