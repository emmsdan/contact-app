module.exports = {
  presets: ["@vue/cli-plugin-babel/preset"],

  plugins: [
    [
      "module-resolver",
      {
        root: ["<rootDir>"],
        alias: {
          "@component": "./src/components/",
          "@view": "./src/views/",
          "@module": "./src/modules/",
          "@http": "./src/services/http",
          "@theme": "./src/theme",
          "@style": "./src/theme/styles.scss",
          "@assets": "./src/assets",
          "@logo": "./src/assets/logo.png",
          "@settings": "./src/settings.json",
          "@root": "./src"
        }
      }
    ]
  ]
};
