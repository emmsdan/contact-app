<template>
  <div class="modal">
    <div class="modal-content"></div>
    <div class="modal-overlay" @click="toggelModal($event)"></div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Emit } from "vue-property-decorator";
import "@theme/_vars.scss";

@Component
export default class Modal extends Vue {
  toggle = false;

  @Emit()
  toggelModal($event: Event): Event {
    this.toggle = !this.toggle;
    return $event;
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.dropdown {
  position: relative;
  display: inline-block;

  .dropbtn {
    background-color: #fff;
    color: rgb(14, 13, 13);
    padding: 10px 16px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
    min-width: 200px;
    height: 40px;
    text-align: initial;
  }

  .dropdown-content {
    position: absolute;
    background-color: #fff;
    width: 100%;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    z-index: 1;
    a {
      padding: 12px 16px;
      display: block;
    }
  }

  &:hover {
    .dropbtn {
      box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.2);
    }
  }
}
</style>
