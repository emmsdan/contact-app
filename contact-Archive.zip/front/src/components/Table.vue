<template>
  <div class="table">
    <div
      class="table__item"
      :class="isCard ? 'card' : ''"
      v-for="data in items"
      :key="data.id"
      @click="select(data, $event)"
    >
      <div class="first">
        <label class="input-check">
          <input type="checkbox" :checked="checked" />
          <span class="checkmark"></span>
        </label>
      </div>
      <div>{{ data.name }}</div>
      <div>{{ data.phone }}</div>
      <div>{{ data.email }}</div>
      <div>{{ data.title }}</div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Emit } from "vue-property-decorator";
import "@theme/_vars.scss";

@Component
export default class AppTable extends Vue {
  @Prop() private items: Array<{}>;
  @Prop() private isCard!: boolean;

  @Emit()
  onRowSelected(selected: object) {
    return selected;
  }

  checked = false;
  activeData = {};

  select(data: null | object, $event: Event) {
    console.log({ data });
    this.onRowSelected(data);
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.table {
  width: 100%;
  // background: red;
  padding: 0;
  margin: 0;
  position: relative;
  display: block;
  &__item {
    position: relative;
    display: flex;
    align-items: center;
    text-align: left;
    padding: 10px;
    .first {
      max-width: 50px !important;
    }
    div {
      // width: 25%;
      flex: 1;
    }
    &.is-header {
      font-weight: 700;
      text-transform: capitalize;
    }
    &.card {
      background: #fff;

      margin: 6px 0;
      border-radius: 50px;
      padding: 15px 10px;
      border: 1px solid #eee;
      div {
        color: rgba(32, 45, 73, 0.685);
      }
      &:hover {
        box-shadow: 0 0.1rem 0.6rem rgba(61, 77, 112, 0.192);
      }
    }
  }
}

/* The container */
.input-check {
  display: block;
  position: relative;
  padding-left: 35px;
  margin-top: -10px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 22px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.input-check input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 20px;
  width: 20px;
  border-radius: 100%;
  border: 1px solid #1f293d3d;
  background-color: none;
}

/* On mouse-over, add a grey background color */
.input-check :hover input ~ .checkmark {
  background-color: #ccc;
}

/* When the checkbox is checked, add a blue background */
.input-check input:checked ~ .checkmark {
  background-color: #3f519e98;
  border: none;
}

/* Create the checkmark/indicator (hidden when not checked) */
.checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.input-check input:checked ~ .checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.input-check .checkmark:after {
  left: 6px;
  top: 3px;
  width: 5px;
  height: 10px;
  border: solid white;
  border-width: 0 3px 3px 0;
  border-radius: 20px;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}
</style>
