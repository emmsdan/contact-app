<template>
  <div class="dropdown">
    <button class="dropbtn" @click="toggleDropdown">Dropdown</button>
    <div class="dropdown-content" v-show="toggle">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import "@theme/_vars.scss";

@Component
export default class Dropdown extends Vue {
  toggle = false;

  toggleDropdown(): void {
    this.toggle = !this.toggle;
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
.dropdown {
  position: relative;
  display: inline-block;

  .dropbtn {
    background-color: #fff;
    color: rgb(14, 13, 13);
    padding: 10px 16px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.2);
    min-width: 200px;
    height: 40px;
    text-align: initial;
  }

  .dropdown-content {
    position: absolute;
    background-color: #fff;
    width: 100%;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
    z-index: 1;
    a {
      padding: 12px 16px;
      display: block;
    }
  }

  &:hover {
    .dropbtn {
      box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.2);
    }
  }
}
</style>
