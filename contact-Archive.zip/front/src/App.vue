<template>
  <Dashboard />
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import Dashboard from "./Dashboard.vue";
@Component({
  components: {
    Dashboard,
  },
})
export default class App extends Vue {}
</script>

<style lang="scss">
body {
  background: #fff;
  margin: 0;
}
</style>
